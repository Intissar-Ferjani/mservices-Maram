package com.intissar.demo.util;

public interface EmailSender {
	void sendEmail(String toEmail, String body);
}
